using UnityEngine;
namespace WesternLemegeton
{
 public partial class GameHUD
 {
  int selectedSigil;
  static string RoomKindName(int i)=>RoomGraph.Kind(i)==ExplorationRoomKind.Sigil?"성흔 강화":RoomGraph.Kind(i)==ExplorationRoomKind.DevilCards?"악마카드 선택":"전투";
  static Vector2 MapPoint(int i,Rect r){var p=RoomGraph.Centers[i];return new Vector2(r.x+p.x/120*r.width,r.yMax-p.y/88*r.height);}
  void DrawExplorationPrompt(Dungeon g)
  {
   if(!g.Running)return;string message="";
   if(g.IsTown){if(g.LocalPos.x>11.5f&&Mathf.Abs(g.LocalPos.y)<2)message="E · 황야로 출발";}
   else
   {
    var door=g.NearbyDoor();
    if(door)message=door.StageExit?(g.Progress.SegmentComplete?"E · 스테이지 출구 / 다음 여정 선택":$"출구 봉인 · 미완료 방 {6-g.MapsCleared}개"):(g.Progress.CanLeave?$"E · {Dungeon.MapNames[door.Destination]} 이동":"문 봉인 · 이 방의 모든 적을 처치하세요");
    else if(g.CurrentKind!=ExplorationRoomKind.Combat&&g.LocalPos.magnitude<2.4f)message=g.Progress.MapComplete?"이 방의 보상을 선택했습니다":g.CurrentKind==ExplorationRoomKind.Sigil?"E · 성흔 제단 / 각인 강화":"E · 악마카드 진열대 / 카드 선택";
   }
   if(message=="")return;Box(new Rect(370,530,540,44),panel);var s=new GUIStyle(body){alignment=TextAnchor.MiddleCenter};s.normal.textColor=Ink.Gold;GUI.Label(new Rect(379,537,522,32),message,s);
  }
  void DrawRoomMinimap(Dungeon g)
  {
   Frame(new Rect(1063,16,190,145),muted*.7f);Rect area=new Rect(1082,34,147,103);
   for(int e=0;e<RoomGraph.Links.GetLength(0);e++)Edge(MapPoint(RoomGraph.Links[e,0],area),MapPoint(RoomGraph.Links[e,1],area),muted*.5f);
   for(int i=0;i<6;i++)
   {
    Vector2 p=MapPoint(i,area);Color c=g.Progress.Cleared(i)?Ink.Gold:g.Progress.Visited(i)?paper:muted*.5f;if(i==g.MapIndex)c=Ink.Cyan;
    Frame(new Rect(p.x-15,p.y-10,30,20),c);
    if(i==g.MapIndex){var local=g.LocalPos;Disc(new Rect(p.x+local.x/15*10-2,p.y-local.y/9*6-2,4,4),Ink.Cyan);}
    else{var s=new GUIStyle(small){alignment=TextAnchor.MiddleCenter};s.normal.textColor=c;GUI.Label(new Rect(p.x-14,p.y-10,28,20),i==2?"성":i==3?"카":(i+1).ToString(),s);}
   }
   if(Button(new Rect(1063,165,190,25),"M · 탐험 지도"))g.OpenRoute();
  }
  void DrawExplorationMap(Dungeon g)
  {
   Overlay();Text(38,25,850,44,"황야 탐험 지도",heading);
   Text(40,72,845,30,g.IsTown?"히르바에서 시작하는 여정 · 각 스테이지는 여섯 방으로 이어집니다":"청록: 현재 위치   ·   금색: 완료   ·   밝은색: 방문   ·   회색: 미방문",small);
   Rect area=new Rect(153,161,587,391);
   for(int e=0;e<RoomGraph.Links.GetLength(0);e++)
   {int a=RoomGraph.Links[e,0],b=RoomGraph.Links[e,1];Edge(MapPoint(a,area),MapPoint(b,area),!g.IsTown&&g.Progress.Visited(a)&&g.Progress.Visited(b)?Ink.Gold:muted*.4f);}
   for(int i=0;i<6;i++)
   {
    Vector2 p=MapPoint(i,area);bool current=!g.IsTown&&i==g.MapIndex,done=!g.IsTown&&g.Progress.Cleared(i),visited=!g.IsTown&&g.Progress.Visited(i);
    Color c=current?Ink.Cyan:done?Ink.Gold:visited?paper:muted*.55f;Rect r=new Rect(p.x-104,p.y-43,208,86);Frame(r,c);
    Text(r.x+12,r.y+10,189,29,$"{i+1:00}  {Dungeon.MapNames[i]}",Style(16,c,FontStyle.Bold));
    Text(r.x+12,r.y+43,190,32,RoomKindName(i)+" · "+(current?"현재 위치":done?"완료":visited?"미완료":"미방문"),small);
   }
   Text(42,619,832,57,g.IsTown?"전투방 4곳 · 성흔 제단 1곳 · 악마카드 방 1곳":"각 방의 문에서 E 키로 이동합니다. 여섯 방의 전투와 보상 선택을 마친 뒤\n06번 방 동쪽 출구와 상호작용하면 다음 스테이지를 선택할 수 있습니다.",small);
   Box(new Rect(920,0,360,720),new Color(.12f,.075f,.15f));Text(945,31,313,41,g.IsTown?"여정의 시작":$"STAGE {g.Room+1:00}",heading);
   Text(946,79,310,34,g.IsTown?"히르바 → 붉은 모래길":Dungeon.RoomNames[g.Room]);
   Text(946,130,304,60,g.IsTown?"황야의 여섯 방을 탐험하세요.":$"방 완료  {g.MapsCleared} / 6\n방 방문  {g.Progress.VisitedMaps} / 6");
   Bar(new Rect(946,210,285,16),g.Hero.Hp/100,Ink.Red,$"HP {Mathf.CeilToInt(g.Hero.Hp)} / 100");
   Text(946,243,288,27,"성흔 각인",small);
   for(int i=0;i<3;i++){Icon(new Rect(946+i*98,277,46,46),buildIcons[i]);Text(949+i*98,329,93,35,g.Build.Stack((SeongheunType)i)+" 각인",small);}
   Text(946,390,290,100,$"악마카드  {g.Build.Passives.Count}장\n공격 +{g.Build.PlayerDamageBonus:P0}  ·  이동 +{g.Build.MoveSpeedBonus:P0}\n까마귀 공격 +{g.Build.RavenDamageBonus:P0}",body);
   if(g.RouteTravel)
   {
    if(!g.IsTown&&g.Room==4){Text(946,499,284,45,"모든 봉인을 해제했습니다.",small);if(Button(new Rect(945,551,309,57),"탐험 완료"))g.FinishExpedition();}
    else{Text(946,490,284,47,"다음: "+Dungeon.RoomNames[g.NextRoom],body);if(Button(new Rect(945,551,309,57),g.IsTown?"황야로 출발":"다음 스테이지로 이동"))g.ChooseRoom(g.NextRoom);}
   }
   else Text(946,506,292,87,g.IsTown?"히르바 동쪽 관문에서 E 키를 눌러 출발하세요.":"다음 스테이지 이동은 여섯 방을 완료한 뒤 출구 문에서 가능합니다.",small);
   if(Button(new Rect(945,641,309,43),"닫기 · M / ESC"))g.CloseRoute();
  }
  void DrawDevilCards(Dungeon g)
  {
   Overlay();Text(101,47,1030,46,"악마카드 · 하나의 계약을 선택하세요",heading);Text(103,106,1020,41,"획득한 카드는 이번 런 동안 유지됩니다. 성흔 각인과 별도로 효과가 누적됩니다.",body);
   string[] names={"탄환의 계약","방랑자의 계약","검은 날개의 계약"},icons={"BulletIcon","WaterIcon","RavenPortrait"};
   float factor=1+.5f*(int)g.CardRarity;
   string[] effects={$"플레이어 공격력 +{.08f*factor:P0}",$"이동 속도 +{.08f*factor:P0}",$"까마귀 공격력 +{.12f*factor:P0}"};
   for(int i=0;i<3;i++)
   {
    float x=102+i*365;Color c=RarityColor(g.CardRarity);Frame(new Rect(x,187,345,400),c);
    Text(x+23,207,296,33,RarityName(g.CardRarity)+" · 악마카드",Style(16,c));Icon(new Rect(x+104,255,135,135),icons[i]);
    Text(x+25,409,297,37,names[i],Style(23,paper,FontStyle.Bold));Text(x+25,456,297,52,effects[i]);
    if(Button(new Rect(x+24,521,297,44),"이 카드 선택"))g.ClaimCard(i);
   }
   if(Button(new Rect(450,631,380,43),"나중에 선택 · ESC"))g.CloseService();
  }
  void DrawSigilPanel(Dungeon g,bool canClaim)
  {
   Overlay();Text(53,32,850,48,"성흔 각인 · SIGIL MANAGEMENT",heading);Text(55,87,920,32,canClaim?"속성을 선택하고 각인을 강화하세요. 이 제단에서는 한 번 강화할 수 있습니다.":"노드를 선택하면 해당 성흔의 각인 수치와 효과를 확인할 수 있습니다.",small);
   Vector2 center=new Vector2(385,335);float radius=184;
   for(int i=0;i<96;i++){float a=i*Mathf.PI*2/96,b=(i+1)*Mathf.PI*2/96;Edge(center+new Vector2(Mathf.Cos(a),Mathf.Sin(a))*radius,center+new Vector2(Mathf.Cos(b),Mathf.Sin(b))*radius,Ink.Red*.65f);}
   Vector2[] points=new Vector2[6];
   for(int i=0;i<6;i++){float a=(-120+i*60)*Mathf.Deg2Rad;points[i]=center+new Vector2(Mathf.Cos(a),Mathf.Sin(a))*radius;}
   for(int i=0;i<3;i++)
   {
    bool active=g.Build.IsActive((SeongheunType)i);Color c=active?Ink.Cyan:muted*.5f;
    Edge(center,points[i*2],c*.65f);Edge(points[i*2],points[i*2+1],c);
   }
   Disc(new Rect(center.x-45,center.y-45,90,90),new Color(.32f,.08f,.2f));Icon(new Rect(center.x-33,center.y-33,66,66),buildIcons[selectedSigil]);
   for(int i=0;i<6;i++)
   {
    int branch=i/2;var type=(SeongheunType)branch;int threshold=g.Build.Threshold(type)+(i%2)*2;bool lit=g.Build.Stack(type)>=threshold;
    Color c=lit?Ink.Cyan:muted*.6f;if(selectedSigil==branch)c=lit?Ink.Gold:paper;
    var p=points[i];Disc(new Rect(p.x-35,p.y-35,70,70),c);Disc(new Rect(p.x-31,p.y-31,62,62),panel);
    var old=GUI.color;GUI.color=lit?Color.white:new Color(.46f,.46f,.58f);Icon(new Rect(p.x-23,p.y-23,46,46),buildIcons[branch]);GUI.color=old;
    if(GUI.Button(new Rect(p.x-39,p.y-39,78,78),GUIContent.none,GUIStyle.none))selectedSigil=branch;
    var s=new GUIStyle(small){alignment=TextAnchor.MiddleCenter};GUI.Label(new Rect(p.x-74,p.y+39,148,26),buildNames[branch]+" · "+threshold+" 각인",s);
   }
   var selected=(SeongheunType)selectedSigil;int stack=g.Build.Stack(selected),level=g.Build.EffectLevel(selected),unlock=g.Build.Threshold(selected);
   Frame(new Rect(733,151,492,402),muted*.6f);Icon(new Rect(760,180,74,74),buildIcons[selectedSigil]);Text(856,182,336,38,buildNames[selectedSigil],heading);
   Text(857,228,329,30,$"각인 {stack}  ·  {(level>0?"활성":"대기")}",Style(19,level>0?Ink.Cyan:muted));
   string[] effects={"공격에 화상을 더해 지속 피해를 줍니다. 각인이 늘수록 화상 피해가 강해집니다.","무기 태그 후 일시적으로 공격력이 증가합니다. 각인이 늘수록 강화량이 커집니다.","까마귀 명령의 공격 시간을 연장하고 연계 공격을 강화합니다. 각인이 늘수록 효과가 강해집니다."};
   Text(761,289,435,100,effects[selectedSigil]);Text(761,397,435,54,$"첫 활성화: {unlock} 각인\n강화 노드: {unlock+2} 각인 · 같은 속성의 효과 누적",small);
   if(canClaim){if(Button(new Rect(760,474,438,51),buildNames[selectedSigil]+$" 각인 +1  ({stack} → {stack+1})"))g.ClaimSigil(selected);}
   else Text(761,478,435,53,"황야의 성흔 제단에서 각인을 강화할 수 있습니다.",small);
   Frame(new Rect(103,602,558,77),Ink.Red*.6f);Text(123,615,518,29,$"선택 성흔  {buildNames[selectedSigil]}   /   각인 {stack}",body);Text(123,646,518,27,"세 속성은 각각 독립적으로 성장합니다.",small);
   if(Button(new Rect(760,610,438,54),canClaim?"나중에 강화 · ESC":"돌아가기 · ESC")){if(canClaim)g.CloseService();else CloseBuildTree();}
  }
 }
}
