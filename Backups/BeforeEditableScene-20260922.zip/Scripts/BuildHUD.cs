using System.Collections.Generic;
using UnityEngine;
namespace WesternLemegeton
{
 public partial class GameHUD
 {
  readonly float[] stackPulse=new float[3];
  readonly Queue<OwnedPassive> passiveNotices=new Queue<OwnedPassive>();
  OwnedPassive toast;float toastRemaining;RunBuild observed;Vector2 passiveScroll;bool buildTree;RunState treeReturn;
  public float StackPulse(SeongheunType type)=>stackPulse[(int)type];
  public int PendingPassiveNotices=>passiveNotices.Count+(toast!=null?1:0);
  void OnEnable(){ConnectBuild();}
  void ConnectBuild(){if(observed||!Dungeon.I||!Dungeon.I.Build)return;observed=Dungeon.I.Build;observed.StackChanged+=OnStackChanged;observed.PassiveAcquired+=OnPassive;observed.Reset+=OnBuildReset;}
  void OnDisable(){if(!observed)return;observed.StackChanged-=OnStackChanged;observed.PassiveAcquired-=OnPassive;observed.Reset-=OnBuildReset;observed=null;}
  void OnStackChanged(SeongheunType type,int oldValue,int newValue){if(newValue>oldValue)stackPulse[(int)type]=.25f;}
  void OnPassive(OwnedPassive item){passiveNotices.Enqueue(item);passiveScroll.x=float.MaxValue;}
  void OnBuildReset(){System.Array.Clear(stackPulse,0,3);passiveNotices.Clear();toast=null;toastRemaining=0;passiveScroll=Vector2.zero;buildTree=false;}
  void Update()
  {
   ConnectBuild();float dt=Time.unscaledDeltaTime;for(int i=0;i<3;i++)stackPulse[i]=Mathf.Max(0,stackPulse[i]-dt);
   if(toast!=null&&Dungeon.I.State!=RunState.Route){toastRemaining-=dt;if(toastRemaining<=0)toast=null;}
   if(toast==null&&passiveNotices.Count>0){toast=passiveNotices.Dequeue();toastRemaining=2.4f;}
   if(buildTree&&Dungeon.I.State!=RunState.Paused)buildTree=false;
  }
  static readonly string[] buildIcons={"FireIcon","NatureIcon","Raven"};
  static readonly string[] buildNames={"잿불","격노","검은 날개"};
  static Color RarityColor(PassiveRarity rarity)=>rarity==PassiveRarity.Common?new Color(.88f,.88f,.91f):rarity==PassiveRarity.Uncommon?new Color(.28f,.65f,1):new Color(.77f,.43f,1);
  static string RarityName(PassiveRarity rarity)=>rarity==PassiveRarity.Common?"일반":rarity==PassiveRarity.Uncommon?"희귀":"레어";
  static string SourceName(PassiveSource source)=>source==PassiveSource.MonsterDrop?"몬스터 드롭":source==PassiveSource.ShopPurchase?"상점 구매":"이벤트 보상";
  void Frame(Rect r,Color color){Box(r,color);Box(new Rect(r.x+2,r.y+2,r.width-4,r.height-4),panel);}
  public void OpenBuildTree(){var g=Dungeon.I;if(!g.Running)return;buildTree=true;treeReturn=g.State;g.BeforePause=g.State;g.State=RunState.Paused;}
  public void CloseBuildTree(){if(!buildTree)return;buildTree=false;Dungeon.I.State=treeReturn;}
  void DrawSeongheun(Dungeon g)
  {
   for(int i=0;i<3;i++)
   {
    var type=(SeongheunType)i;bool unlocked=g.Build.IsActive(type);bool active=unlocked&&(i!=1||g.Hero.Fury>0);
    float pulse=Mathf.Sin((1-stackPulse[i]/.25f)*Mathf.PI),size=48*(1+.22f*pulse);float x=1008+i*87,y=638;
    Color edge=stackPulse[i]>0?Color.white:active?Ink.Gold:unlocked?Ink.Cyan:muted*.6f;
    Frame(new Rect(x-size/2-3,y-size/2-3,size+6,size+6),edge);var old=GUI.color;GUI.color=unlocked?Color.white:new Color(.5f,.5f,.55f);Icon(new Rect(x-size/2,y-size/2,size,size),buildIcons[i]);GUI.color=old;
    Text(x-27,671,86,23,"각인 "+g.Build.Stack(type),small);
    if(GUI.Button(new Rect(x-30,607,67,92),GUIContent.none,GUIStyle.none)&&g.Running){OpenBuildTree();}
   }
  }
  void DrawPassives(Dungeon g)
  {
   var items=g.Build.Passives;Text(27,98,520,23,$"획득 패시브  {items.Count}  ·  성흔과 별도",small);
   if(items.Count==0){Text(28,126,370,23,"획득한 아이템이 없습니다",small);return;}
   passiveScroll=GUI.BeginScrollView(new Rect(25,124,425,74),passiveScroll,new Rect(0,0,Mathf.Max(409,items.Count*59),52));
   for(int i=0;i<items.Count;i++){var item=items[i];Rect r=new Rect(i*59,0,51,51);Frame(r,RarityColor(item.Rarity));Icon(new Rect(r.x+5,5,41,41),item.Definition.Icon);GUI.Label(r,new GUIContent("",item.Definition.Name+" · "+RarityName(item.Rarity)+" · "+SourceName(item.Source)),GUIStyle.none);}
   GUI.EndScrollView();
   if(!string.IsNullOrEmpty(GUI.tooltip)){Box(new Rect(26,201,490,31),panel);Text(34,205,475,27,GUI.tooltip,small);}
  }
  void DrawPassiveToast()
  {
   if(buildTree)DrawBuildTree(Dungeon.I);
   if(toast==null||Dungeon.I.State==RunState.Route)return;
   float fade=Mathf.Min(1,(2.4f-toastRemaining)/.15f,toastRemaining/.3f);var old=GUI.color;GUI.color=new Color(1,1,1,Mathf.Clamp01(fade));
   Rect r=new Rect(458,buildTree||Dungeon.I.State==RunState.SigilChoice?12:106,430,91);Frame(r,RarityColor(toast.Rarity));Icon(new Rect(r.x+14,r.y+12,65,65),toast.Definition.Icon);
   Text(r.x+96,r.y+13,322,30,toast.Definition.Name);Text(r.x+96,r.y+48,322,28,RarityName(toast.Rarity)+" · "+SourceName(toast.Source),small);GUI.color=old;
  }
  void DrawBuildTree(Dungeon g){DrawSigilPanel(g,false);}
 }
}


