﻿using UnityEngine;
namespace WesternLemegeton
{
 public partial class GameHUD:MonoBehaviour
 {
  Font font;GUIStyle small,body,heading,button;bool ready,settings;Texture2D vignette;
  public bool SettingsOpen=>settings;public void CloseSettings(){settings=false;}
  Color paper=new Color(.97f,.89f,.72f),muted=new Color(.71f,.64f,.64f),panel=new Color(.09f,.055f,.105f,.94f);
  void Init()
  {
   font=Font.CreateDynamicFontFromOSFont(new[]{"Malgun Gothic","Arial"},18);small=Style(13,muted);body=Style(17,paper);heading=Style(27,paper,FontStyle.Bold);button=Style(16,paper,FontStyle.Bold);button.alignment=TextAnchor.MiddleCenter;
   button.normal.background=Texture2D.whiteTexture;button.hover.background=Texture2D.whiteTexture;button.active.background=Texture2D.whiteTexture;button.hover.textColor=Color.white;button.active.textColor=Color.white;
   vignette=new Texture2D(128,72,TextureFormat.RGBA32,false);var pixels=new Color[128*72];
   for(int y=0;y<72;y++)for(int x=0;x<128;x++){float d=new Vector2((x-63.5f)/75,(y-35.5f)/43).magnitude;pixels[y*128+x]=new Color(.025f,.008f,.05f,Mathf.SmoothStep(0,.82f,Mathf.InverseLerp(.45f,1.15f,d)));}vignette.SetPixels(pixels);vignette.Apply();ready=true;
  }
  GUIStyle Style(int size,Color c,FontStyle weight=FontStyle.Normal){var s=new GUIStyle{font=font,fontSize=size,fontStyle=weight,wordWrap=true};s.normal.textColor=c;return s;}
  void Box(Rect r,Color c){var old=GUI.color;GUI.color=c*old;GUI.DrawTexture(r,Texture2D.whiteTexture);GUI.color=old;}
  void Disc(Rect r,Color c){var old=GUI.color;GUI.color=c;GUI.DrawTexture(r,Ink.Disc.texture);GUI.color=old;}
  void Text(float x,float y,float w,float h,string text,GUIStyle style=null){GUI.Label(new Rect(x,y,w,h),text,style??body);}
  bool Button(Rect r,string label){var old=GUI.backgroundColor;GUI.backgroundColor=new Color(.26f,.15f,.21f);bool pressed=GUI.Button(r,label,button);GUI.backgroundColor=old;return pressed;}
  void Icon(Rect r,string name)
  {
   var sprite=CombatArt.Get(name);var b=sprite.rect;float ratio=b.width/b.height;Rect fit=r;if(r.width/r.height>ratio){fit.width=r.height*ratio;fit.x+=(r.width-fit.width)/2;}else{fit.height=r.width/ratio;fit.y+=(r.height-fit.height)/2;}
   GUI.DrawTextureWithTexCoords(fit,sprite.texture,new Rect(b.x/sprite.texture.width,b.y/sprite.texture.height,b.width/sprite.texture.width,b.height/sprite.texture.height));
  }
  void OnGUI()
  {
   if(!ready)Init();GUI.matrix=Matrix4x4.TRS(Vector3.zero,Quaternion.identity,new Vector3(Screen.width/1280f,Screen.height/720f,1));var g=Dungeon.I;if(!g||!g.Hero)return;
   if(g.State==RunState.Cinematic){DrawCinematic(g);return;}
   if(g.State==RunState.Title){Title(g);return;}
   GUI.DrawTexture(new Rect(0,0,1280,720),vignette);
   Text(25,20,820,36,g.IsTown?"HIRVA  /  히르바":$"스테이지 {g.Room+1:00} · 방 {g.MapIndex+1}/6  /  {Dungeon.MapNames[g.MapIndex]}",heading);
   Text(27,59,780,26,g.Notice!=""?g.Notice:g.IsTown?"WASD 이동 · 동쪽 관문 E · M 이동 지도":$"남은 적 {g.Enemies.Count}  ·  처치 {g.Kills}  ·  {(int)g.RunTime/60:00}:{(int)g.RunTime%60:00}",small);
   Minimap(g);
   Box(new Rect(1110,199,143,72),panel);Text(1121,210,128,54,$"보급품  {g.Supplies}\n방 완료  {g.MapsCleared} / 6",small);
   if(!g.IsTown&&g.CurrentKind==ExplorationRoomKind.Combat){Box(new Rect(491,91,343,40),panel);Text(510,98,318,32,$"WAVE {g.WaveIndex+1} / {g.WavesInMap}    ·    남은 적 {g.Enemies.Count}");}
   if(g.State==RunState.WaveBreak){Box(new Rect(436,255,410,90),panel);Text(465,270,360,40,$"다음 WAVE {g.WaveIndex+1}",heading);Text(466,309,360,30,$"{Mathf.CeilToInt(g.WaveCountdown)}초 후 적이 접근합니다",body);}
   var p=g.Hero;
   Text(27,605,430,23,$"회피 {(p.DashCd>0?p.DashCd.ToString("F1")+"s":"●")}    COMBO {p.HitCombo}    {(p.Fury>0?"태그 강화":"")}",small);
   Bar(new Rect(27,638,322,16),p.Hp/100,Ink.Red,$"{Mathf.CeilToInt(p.Hp)} / 100");
   Bar(new Rect(27,664,322,13),p.Ammo/6f,Ink.Cyan,p.Reload>0?$"장전 {p.Reload:F1}s · {p.Ammo} / 6":$"리볼버 {p.Ammo} / 6");
   Slot(382,"Q",p.Weapon==0?"SlashIcon":"ShotIcon",p.TagCd,p.Weapon==0?"단검":"리볼버");
   Slot(469,"SPACE","HunterDash",p.DashCd,"회피");
   Slot(556,"2",p.Weapon==0?"SlashIcon":"ShotIcon",p.Skill2Cd,p.Weapon==0?"베어 가르기":"원 샷");
   Slot(643,"3",p.Weapon==0?"SlamIcon":"BarrageIcon",p.Skill3Cd,p.Weapon==0?"내려찍기":"난사");
   Slot(730,"1","Raven",g.Crow.Cooldown,g.Crow.Active>0?$"공격 {g.Crow.Active:F1}s":"까마귀 명령");
   Slot(817,"R","RavenPortrait",g.Crow.LinkCooldown,g.Crow.LinkWindow>0?$"연계 {g.Crow.LinkWindow:F1}s":"연계 대기",g.Crow.LinkWindow>0);
   string[] stigma={"FireIcon","NatureIcon","RavenLink"};int[] levels={g.BurnLevel,g.FuryLevel,g.RavenLevel};
   DrawSeongheun(g);DrawPassives(g);
   if(g.Crow.LinkWindow>0||g.Crow.ComboFlash>0)
   {Vector2 at=PaperWorld.Screen(g.Cam,g.Pos,2.3f);Disc(new Rect(at.x-48,at.y-43,96,55),paper);Icon(new Rect(at.x-39,at.y-41,35,43),"RavenPortrait");var dark=Style(15,panel,FontStyle.Bold);Text(at.x-2,at.y-30,45,36,g.Crow.LinkWindow>0?$"R\n{g.Crow.LinkWindow:F0}s":"연계!",dark);}
   DrawExplorationPrompt(g);
   if(g.IsBossWave&&g.Enemies.Count>0&&g.Enemies[0])Bar(new Rect(415,95,450,14),g.Enemies[0].Hp/g.Enemies[0].MaxHp,Ink.Red,"봉인의 파수꾼");
   if(g.State==RunState.Route)DrawExplorationMap(g);
   if(g.State==RunState.SigilChoice)DrawSigilPanel(g,true);if(g.State==RunState.CardChoice)DrawDevilCards(g);
   if(g.State==RunState.Paused){Overlay();Text(430,210,480,45,"잠시 숨을 고르다",heading);Text(430,273,480,100,"WASD 달리기 · SHIFT 걷기 · 좌클릭 공격\nQ 태그 · SPACE 회피 · 2 / 3 기술\n1 까마귀 명령 · R 연계 · M 지도",body);if(Button(new Rect(430,390,420,52),"계속하기"))g.State=g.BeforePause;if(Button(new Rect(430,458,420,48),"설정"))settings=true;}
   if(g.State==RunState.Dead||g.State==RunState.Victory){Overlay();Text(330,240,650,65,g.State==RunState.Victory?"봉인이 무너졌다":"다시, 잿빛 황야로",heading);Text(330,317,650,35,$"도달 {g.Room+1} / 5  ·  처치 {g.Kills}  ·  {(int)g.RunTime}초");if(Button(new Rect(330,410,620,60),"히르바로 돌아가기"))g.EnterTown();}
   if(settings)Settings();DrawPassiveToast();
  }
  void Bar(Rect r,float value,Color c,string label){Box(new Rect(r.x-3,r.y-3,r.width+6,r.height+6),panel);Box(r,new Color(.18f,.12f,.2f));Box(new Rect(r.x,r.y,r.width*Mathf.Clamp01(value),r.height),c);var s=new GUIStyle(small){alignment=TextAnchor.MiddleCenter};s.normal.textColor=Color.white;GUI.Label(new Rect(r.x,r.y-3,r.width,22),label,s);}
  void Slot(float x,string key,string asset,float cd,string label,bool lit=false)
  {Box(new Rect(x,610,69,67),lit?new Color(.65f,.39f,.19f):panel);Icon(new Rect(x+6,617,57,52),asset);Text(x,587,90,20,key,small);if(cd>0){Box(new Rect(x,610,69,67),new Color(0,0,0,.67f));Text(x+16,632,62,25,cd.ToString("F1"));}Text(x-6,684,96,25,label,small);}
  void Overlay(){Box(new Rect(0,0,1280,720),new Color(.025f,.015f,.04f,1));}
  void Title(Dungeon g)
  {
   GUI.DrawTexture(new Rect(0,0,1280,720),CombatArt.Texture("Title"),ScaleMode.ScaleToFit);
   if(!settings){if(GUI.Button(new Rect(34,435,263,97),GUIContent.none,GUIStyle.none))g.EnterTown();if(GUI.Button(new Rect(39,546,267,71),GUIContent.none,GUIStyle.none))g.EnterTown();if(GUI.Button(new Rect(49,635,239,70),GUIContent.none,GUIStyle.none))settings=true;}
   Box(new Rect(947,654,316,48),panel);Text(962,663,293,32,"히르바 · 저주받은 황야",body);if(settings)Settings();DrawPassiveToast();
  }
  void Settings()
  {Overlay();Text(431,210,450,45,"설정",heading);Text(431,290,450,27,"효과음 음량");AudioListener.volume=GUI.HorizontalSlider(new Rect(431,333,418,25),AudioListener.volume,0,1);if(Button(new Rect(431,389,418,48),Screen.fullScreen?"창 모드로 전환":"전체 화면으로 전환"))Screen.fullScreen=!Screen.fullScreen;if(Button(new Rect(431,463,418,48),"돌아가기"))settings=false;}
  void Minimap(Dungeon g)
  {
   if(!g.IsTown){DrawRoomMinimap(g);return;}
   Rect r=new Rect(1101,21,152,152);Disc(new Rect(1097,17,160,160),muted);Disc(r,panel);Dot(r,g.Pos,Ink.Cyan,7);Dot(r,g.Crow.transform.position,Ink.Gold,4);Dot(r,new Vector2(13,0),Ink.Cyan,7);
   if(Button(new Rect(1107,165,140,25),"M · 탐험 지도"))g.OpenRoute();
  }  void Dot(Rect r,Vector2 p,Color c,float size){Vector2 offset=new Vector2(p.x/16,-p.y/10)*57;if(offset.magnitude>64)offset=offset.normalized*64;Disc(new Rect(r.center.x+offset.x-size/2,r.center.y+offset.y-size/2,size,size),c);}
  void Edge(Vector2 a,Vector2 b,Color color){var old=GUI.matrix;Vector2 d=b-a;GUIUtility.RotateAroundPivot(Mathf.Atan2(d.y,d.x)*Mathf.Rad2Deg,a);Box(new Rect(a.x,a.y-2,d.magnitude,4),color);GUI.matrix=old;}
 }
}



