using UnityEngine;
using UnityEngine.Rendering;

namespace WesternLemegeton
{
    // Gameplay stays in XY. Visible cards live in XZ with a perspective camera.
    // A separate render representation prevents 3D presentation from changing combat distances.
    [DefaultExecutionOrder(200)]
    public class PaperWorld:MonoBehaviour
    {
        public const int LogicLayer=30;
        public const float Pitch=47;
        public static Vector3 Point(Vector2 p,float height=0)=>new Vector3(p.x,height,p.y);
        public static void Attach(SpriteRenderer source,bool flat)
        {
            if(!Application.isPlaying)return;
            source.gameObject.layer=LogicLayer;
            var card=source.gameObject.AddComponent<PaperCard>();card.Source=source;card.Flat=flat;
        }
        public static Vector2 Mouse(Camera camera,Vector3 screen)
        {
            var ray=camera.ScreenPointToRay(screen);
            if(new Plane(Vector3.up,Vector3.zero).Raycast(ray,out float distance)){var p=ray.GetPoint(distance);return new Vector2(p.x,p.z);}return Vector2.zero;
        }
        public static Vector2 Screen(Camera camera,Vector2 logical,float height=0)
        {var p=camera.WorldToScreenPoint(Point(logical,height));return new Vector2(p.x/UnityEngine.Screen.width*1280,(1-p.y/UnityEngine.Screen.height)*720);}
        public static void Configure(Camera camera)
        {
            camera.orthographic=false;camera.fieldOfView=38;camera.nearClipPlane=.1f;camera.farClipPlane=130;
            camera.rect=new Rect(0,0,1,1);camera.cullingMask=~(1<<LogicLayer);
            camera.backgroundColor=new Color(.08f,.065f,.10f);camera.transform.rotation=Quaternion.Euler(Pitch,0,0);
        }
        public static Vector3 CameraPosition(Vector2 focus)
        {
            var angle=Quaternion.Euler(Pitch,0,0);
            return Point(focus,1.5f)-angle*Vector3.forward*26;
        }
    }
    [DefaultExecutionOrder(300)]
    public class PaperCard:MonoBehaviour
    {
        public SpriteRenderer Source;public bool Flat;public Vector3 RenderOffset;
        SpriteRenderer visible;SortingGroup group;PropGrounding grounding;
        void Start()
        {
            visible=new GameObject("Card / "+name,typeof(SpriteRenderer)).GetComponent<SpriteRenderer>();
            group=GetComponentInParent<SortingGroup>();
            var landscape=GetComponent<LandscapeParallax>();
            string asset=Source.sprite?Source.sprite.name:"";
            bool scenery=asset.StartsWith("Wnn")||asset.StartsWith("OBJ")||asset.StartsWith("Deco")||asset.StartsWith("Fence");
            // Dust veils and skill effects are also cards, but must never cast prop shadows.
            if(scenery && !Flat && Source.sprite && Source.sprite.bounds.size.y*Mathf.Abs(transform.lossyScale.y)>.75f && !group && (!landscape || landscape.Factor<=0))
                grounding=new PropGrounding(Source);
        }
        void LateUpdate()
        {
            if(!visible||!Source)return;
            visible.enabled=Source.enabled && Source.gameObject.activeInHierarchy;
            visible.sprite=Source.sprite;visible.flipX=Source.flipX;visible.flipY=Source.flipY;
            visible.sharedMaterial=Source.sharedMaterial;
            Color tint=Source.color;
            if(!group && !Flat)tint*=new Color(.94f,.85f,.80f,1);
            visible.color=tint;
            visible.sortingOrder=group?group.sortingOrder*10+Source.sortingOrder:Source.sortingOrder*10;
            var scale=transform.lossyScale;visible.transform.localScale=new Vector3(scale.x,scale.y,1);
            float height=Flat?.015f:0;
            visible.transform.position=PaperWorld.Point(transform.position,height)+RenderOffset;
            visible.transform.rotation=Quaternion.Euler(Flat?90:PaperWorld.Pitch,0,0)*Quaternion.Euler(0,0,transform.eulerAngles.z);
            grounding?.Update(visible,Dungeon.I?Dungeon.I.Cam:Camera.main);
        }
        void OnDisable(){if(visible)visible.enabled=false;grounding?.SetVisible(false);}
        void OnDestroy(){if(visible)Destroy(visible.gameObject);grounding?.Dispose();}
    }
}


