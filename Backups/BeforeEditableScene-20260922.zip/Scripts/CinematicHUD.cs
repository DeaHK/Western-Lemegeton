using UnityEngine;
namespace WesternLemegeton
{
 public partial class GameHUD
 {
  Texture2D cinematicScrim;
  void DrawCinematic(Dungeon g)
  {
   var c=g.Cinematics;GUI.DrawTexture(new Rect(0,0,1280,720),vignette);
   if(!cinematicScrim){cinematicScrim=new Texture2D(1,64,TextureFormat.RGBA32,false);cinematicScrim.wrapMode=TextureWrapMode.Clamp;for(int i=0;i<64;i++)cinematicScrim.SetPixel(0,i,new Color(.015f,.008f,.025f,Mathf.SmoothStep(.72f,0,i/63f)));cinematicScrim.Apply();}
   float bar=67*c.Letterbox;Box(new Rect(0,0,1280,bar),Color.black);Box(new Rect(0,720-bar,1280,bar),Color.black);
   if(c.TitleOpacity>0)
   {
    var old=GUI.color;GUI.color=new Color(1,1,1,c.TitleOpacity);
    GUI.DrawTexture(new Rect(0,444,1280,220),cinematicScrim);
    var centered=Style(c.Kind==CinematicKind.BossEntrance?43:36,paper,FontStyle.Bold);centered.alignment=TextAnchor.MiddleCenter;
    var sub=Style(17,muted);sub.alignment=TextAnchor.MiddleCenter;
    Box(new Rect(350,487,580,3),c.Kind==CinematicKind.BossEntrance?Ink.Red:Ink.Gold);
    GUI.Label(new Rect(180,509,920,63),c.Heading,centered);GUI.Label(new Rect(220,577,840,35),c.Caption,sub);GUI.color=old;
   }
   if(c.Shade>0)Box(new Rect(0,0,1280,720),new Color(0,0,0,c.Shade));
   Text(820,684,430,27,c.IsPaused?"연출 일시정지 · P 계속 · SPACE 건너뛰기":"SPACE / ESC 건너뛰기 · P 일시정지",small);
  }
 }
}
